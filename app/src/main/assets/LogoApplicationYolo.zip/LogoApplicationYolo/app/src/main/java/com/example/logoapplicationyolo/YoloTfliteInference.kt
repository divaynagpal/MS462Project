package com.example.logoapplicationyolo

import android.content.res.AssetManager
import android.graphics.Bitmap
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.io.FileInputStream
import java.io.IOException

class YoloTfliteInference(private val modelPath: String, assetManager: AssetManager) {

    private var interpreter: Interpreter? = null
    private val merchantLabels = listOf(
        "Nike", "Starbucks")


                init {
        try {
            interpreter = Interpreter(loadModelFile(modelPath, assetManager))
        } catch (e: IOException) {
            Log.e("TFLite", "Error loading model: ${e.message}")
        }
    }

   /* private fun loadModelFile(modelPath: String): MappedByteBuffer {
        val fileDescriptor = FileInputStream(modelPath).channel
        return fileDescriptor.map(FileChannel.MapMode.READ_ONLY, 0, fileDescriptor.size())
    }*/

    private fun loadModelFile(modelPath: String, assetManager: AssetManager): MappedByteBuffer {
        val assetFileDescriptor = assetManager.openFd(modelPath)
        val inputStream = FileInputStream(assetFileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, assetFileDescriptor.startOffset, assetFileDescriptor.declaredLength)
    }


    fun runInference(bitmap: Bitmap): String {
        val inputBuffer = preprocessImage(bitmap)
        val outputBuffer = Array(1) { Array(6) { FloatArray(8400) } }

        interpreter?.run(inputBuffer, outputBuffer)

        return processOutput(outputBuffer)
    }

    private fun preprocessImage(bitmap: Bitmap): ByteBuffer {
        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 640, 640, true)
        val inputBuffer = ByteBuffer.allocateDirect(4 * 640 * 640 * 3).apply {
            order(ByteOrder.nativeOrder())
        }

        val intValues = IntArray(640 * 640)
        resizedBitmap.getPixels(intValues, 0, 640, 0, 0, 640, 640)

        for (pixelValue in intValues) {
            val r = (pixelValue shr 16 and 0xFF) / 255.0f
            val g = (pixelValue shr 8 and 0xFF) / 255.0f
            val b = (pixelValue and 0xFF) / 255.0f
            inputBuffer.putFloat(r)
            inputBuffer.putFloat(g)
            inputBuffer.putFloat(b)
        }

        return inputBuffer
    }

   /* private fun processOutput(outputBuffer: Array<FloatArray>): String {
        print(outputBuffer)
        val maxIndex = outputBuffer[0].indices.maxByOrNull { outputBuffer[0][it] } ?: -1
        return "Detected Merchant: Merchant_$maxIndex"
    }*/

    private fun processOutput(outputBuffer: Array<Array<FloatArray>>): String {
        // Extract confidence scores and bounding box information
        var bestIndex = -1
        var bestConfidence = 0f
        var detectedClass = -1

        for (i in outputBuffer[0][4].indices) {
            val confidence = outputBuffer[0][4][i] // Confidence score
            val classIndex = outputBuffer[0][5][i].toInt() // Class index
            if (confidence > bestConfidence) {
                bestConfidence = confidence
                bestIndex = i
                detectedClass = classIndex
            }
        }

        return if (bestIndex != -1 && detectedClass in merchantLabels.indices) {
            "Detected Merchant: ${merchantLabels[detectedClass]} with confidence: $bestConfidence"
        } else {
            "No merchant detected."
        }
    }
}

